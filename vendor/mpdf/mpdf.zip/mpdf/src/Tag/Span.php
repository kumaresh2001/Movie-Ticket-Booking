<?php

namespace Mpdf\Tag;

class Span extends InlineTag
{


}
