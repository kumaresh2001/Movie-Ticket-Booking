<?php

namespace Mpdf\Tag;

class Acronym extends InlineTag
{


}
